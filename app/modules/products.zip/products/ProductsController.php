<?php
namespace app\modules\products;

use app\core\Controller;
use app\modules\products\classes\Products;

class ProductsController implements Controller {

    public function Route($data)
    {
        $jsondata = $data["JSON"];

        switch ($data["Page_key"]) {
            
            case 'getProducts':
                 return (new Products())->getProducts();

            case 'getProducts_subscription':
                    return (new Products())->getProducts_subscription();

            case 'addProduct':
                return (new Products())->addProduct($jsondata );
                
            case 'addProductSubscription':
                 return (new Products())->addProductSubscription($jsondata );
                 
            case 'getProductsubscription':
                return (new Products())->getProductsubscription($jsondata );

            case 'getActiveProductSubscription':
                return (new Products())->getActiveProductSubscription($jsondata );

                
                
            case 'deleteProduct':
                return (new Products())->deleteProduct($jsondata );

            case 'getProductModule':
                return (new Products())->getProductModule($jsondata );

            case 'deleteProductSubscription':
                    return (new Products())->deleteProductSubscription($jsondata );

            case 'getProductVersion':
                return (new Products())->getProductVersion($jsondata );
            case 'getAllProduct':
                return (new Products())->getAllProduct($jsondata );
        
            case 'getProductVersionBasedonProductID':
                return (new Products())->getProductVersionBasedonProductID($jsondata );
                
            case 'updateProductVersion':
                return (new Products())->updateProductVersion($jsondata);
                
                    

                
                
                    
                    
            default:
                header('HTTP/1.1 401  Unauthorized Access');
                header("Status: 401 ");
                session_destroy();
                return array("return_code" => false, "return_data" => array("Page Key not found"));
        }
    }

    public static function Views($page)
    {

        $viewpath = "../app/modules/products/views/";

        switch ($page[1]) {

            case 'product':
                load($viewpath . "product.php");
                break;
            case 'productsubscription':
                load($viewpath . "productsubscription.php");
                break;
            case 'productversion':
                load($viewpath . "productversion.php");
                break;
                    

            default:
                // session_destroy();
                include '404.php';
                header('HTTP/1.1 401  Unauthorized Access');
                header("Status: 401 ");
                break;
        }
    }
}